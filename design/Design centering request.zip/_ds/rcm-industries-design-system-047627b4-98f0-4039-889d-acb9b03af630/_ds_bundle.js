/* @ds-bundle: {"format":4,"namespace":"RCMIndustriesDesignSystem_047627","components":[{"name":"AppShell","sourcePath":"components/app/AppShell.jsx"},{"name":"AuthCard","sourcePath":"components/app/AuthCard.jsx"},{"name":"Dropdown","sourcePath":"components/controls/Dropdown.jsx"},{"name":"PageNav","sourcePath":"components/controls/PageNav.jsx"},{"name":"Slicer","sourcePath":"components/controls/Slicer.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"StatusPill","sourcePath":"components/core/StatusPill.jsx"},{"name":"BarChart","sourcePath":"components/data/BarChart.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"KpiCallout","sourcePath":"components/data/KpiCallout.jsx"},{"name":"LineChart","sourcePath":"components/data/LineChart.jsx"}],"sourceHashes":{"components/app/AppShell.jsx":"f18f6945307f","components/app/AuthCard.jsx":"b40306c05e12","components/controls/Dropdown.jsx":"42b1a0a57748","components/controls/PageNav.jsx":"37294578d509","components/controls/Slicer.jsx":"34ff4285c15b","components/core/Button.jsx":"069061a3a380","components/core/Card.jsx":"b42efe56a40d","components/core/StatusPill.jsx":"581d09b0619e","components/data/BarChart.jsx":"8547442b6c33","components/data/DataTable.jsx":"a95571d91015","components/data/KpiCallout.jsx":"c7d307efa8af","components/data/LineChart.jsx":"46e6418ec98e","ui_kits/powerbi_report/ArAging.jsx":"5a0f0af83512","ui_kits/powerbi_report/ExecutiveSummary.jsx":"3f9b538d9a8b","ui_kits/powerbi_report/OpenOrders.jsx":"1e3b19c27898","ui_kits/powerbi_report/ReportFrame.jsx":"20e0812278f0","ui_kits/powerbi_report/SixMonthForecast.jsx":"085c2dcb2198","ui_kits/powerbi_report/data.js":"c2bc7f939822","ui_kits/rayfin_app/ArDashboard.jsx":"a9c51e3ae99c","ui_kits/rayfin_app/ArReview.jsx":"1244b984e1a2","ui_kits/rayfin_app/CustomerDetail.jsx":"c9a9d4c4ac11","ui_kits/rayfin_app/data.js":"d92242fa23bd"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.RCMIndustriesDesignSystem_047627 = window.RCMIndustriesDesignSystem_047627 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/app/AppShell.jsx
try { (() => {
/**
 * The standard RCM Rayfin app shell: brand logo · separator · title/subtitle ·
 * [context] … [actions] · user · sign out, over the flat Modern Teal canvas.
 * Header is 64px, sticky, white on a hairline border. Recreation of
 * rayfin-ui/src/components/rcm/app-shell.tsx.
 */
function AppShell({
  title,
  subtitle,
  context,
  actions,
  userName,
  onSignOut,
  logoSrc,
  maxWidth = 1600,
  children
}) {
  const container = {
    margin: '0 auto',
    width: '100%',
    maxWidth,
    padding: '0 24px'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: 'var(--bg-page)',
      color: 'var(--fg-2)'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 30,
      borderBottom: '1px solid var(--border)',
      background: 'var(--bg-card)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...container,
      display: 'flex',
      height: 64,
      alignItems: 'center',
      gap: 12
    }
  }, logoSrc ? /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "RCM Industries",
    style: {
      height: 36,
      width: 'auto',
      flex: 'none'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 18,
      color: 'var(--teal)',
      letterSpacing: '0.02em'
    }
  }, "RCM"), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 32,
      width: 1,
      background: 'var(--border)',
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0,
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 20,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--fg-1)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--fg-2)'
    }
  }, subtitle)), context && /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 8,
      display: 'flex',
      alignItems: 'center',
      flex: 'none'
    }
  }, context), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      flex: 'none'
    }
  }, actions, userName && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--fg-2)',
      maxWidth: 180,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, userName), onSignOut && /*#__PURE__*/React.createElement("button", {
    onClick: onSignOut,
    style: {
      height: 32,
      padding: '0 12px',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      background: 'var(--bg-card)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-chip)',
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 12,
      color: 'var(--deep-teal)',
      cursor: 'pointer'
    }
  }, "Sign out")))), /*#__PURE__*/React.createElement("main", {
    style: {
      ...container,
      padding: '24px'
    }
  }, children));
}
Object.assign(__ds_scope, { AppShell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/app/AppShell.jsx", error: String((e && e.message) || e) }); }

// components/app/AuthCard.jsx
try { (() => {
const MS_SQUARES = [['#f25022', 1, 1], ['#7fba00', 11, 1], ['#00a4ef', 1, 11], ['#ffb900', 11, 11]];

/**
 * The standard RCM sign-in card — logo, app title/subtitle, and the shared
 * "Sign in with Microsoft" button on the flat Modern Teal page. Recreation of
 * rayfin-ui/src/components/rcm/auth-page.tsx.
 */
function AuthCard({
  title,
  subtitle = 'Sign in with your RCM account to continue.',
  footer,
  onSignIn,
  fabricAuthEnabled = true,
  logoSrc,
  loading = false,
  error
}) {
  const [hover, setHover] = React.useState(false);
  const label = loading ? fabricAuthEnabled ? 'Opening Fabric…' : 'Signing in…' : fabricAuthEnabled ? 'Sign in with Microsoft' : 'Continue in local development';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100%',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 16,
      background: 'var(--bg-page)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 384
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-card)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-card)',
      boxShadow: 'var(--shadow-card)',
      padding: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      marginBottom: 32
    }
  }, logoSrc ? /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "RCM Industries",
    style: {
      height: 40,
      width: 'auto',
      marginBottom: 20
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 26,
      color: 'var(--teal)',
      marginBottom: 20
    }
  }, "RCM"), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 20,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--fg-1)'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '8px 0 0',
      fontSize: 13,
      color: 'var(--fg-2)'
    }
  }, subtitle)), /*#__PURE__*/React.createElement("button", {
    onClick: onSignIn,
    disabled: loading,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: '100%',
      height: 36,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      background: hover && !loading ? 'var(--deep-teal)' : 'var(--teal)',
      color: '#fff',
      border: '1px solid transparent',
      borderRadius: 'var(--radius-chip)',
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 12,
      cursor: loading ? 'default' : 'pointer',
      transition: 'background-color var(--dur-1) var(--ease-out)'
    }
  }, fabricAuthEnabled && /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 21 21",
    "aria-hidden": "true"
  }, MS_SQUARES.map(([c, x, y]) => /*#__PURE__*/React.createElement("rect", {
    key: c,
    x: x,
    y: y,
    width: "9",
    height: "9",
    fill: c
  }))), label), error && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '12px 0 0',
      textAlign: 'center',
      fontSize: 13,
      color: 'var(--bad)'
    }
  }, error)), footer && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '16px 0 0',
      textAlign: 'center',
      fontSize: 11,
      color: 'var(--fg-3)'
    }
  }, footer)));
}
Object.assign(__ds_scope, { AuthCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/app/AuthCard.jsx", error: String((e && e.message) || e) }); }

// components/controls/Dropdown.jsx
try { (() => {
/**
 * Dropdown — control r6 with --border-strong, hover border -> teal. Menu at
 * --shadow-menu, r8; item hover --tint-hover; selected --tint-selected +
 * deep-teal semibold (DESIGN.md §9.6).
 */
function Dropdown({
  label,
  options,
  value,
  onChange,
  width = 150,
  size = 'md'
}) {
  const [open, setOpen] = React.useState(false);
  const [hoverCtl, setHoverCtl] = React.useState(false);
  const [hoverIdx, setHoverIdx] = React.useState(-1);
  const ref = React.useRef(null);
  React.useEffect(() => {
    const away = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', away);
    return () => document.removeEventListener('mousedown', away);
  }, []);
  const norm = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  const current = norm.find(o => o.value === value);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    style: {
      position: 'relative',
      width,
      flex: 'none'
    }
  }, label && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--fg-3)',
      marginBottom: 4
    }
  }, label), /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(o => !o),
    onMouseEnter: () => setHoverCtl(true),
    onMouseLeave: () => setHoverCtl(false),
    style: {
      width: '100%',
      height: size === 'sm' ? 26 : 30,
      padding: '0 9px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 6,
      background: 'var(--bg-card)',
      color: 'var(--fg-1)',
      border: '1px solid ' + (open || hoverCtl ? 'var(--teal)' : 'var(--border-strong)'),
      borderRadius: 'var(--radius-control)',
      fontSize: 12,
      fontFamily: 'var(--font-sans)',
      cursor: 'pointer',
      textAlign: 'left',
      transition: 'border-color var(--dur-1) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, current ? current.label : 'Select…'), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fg-3)',
      fontSize: 9,
      lineHeight: 1
    }
  }, "\u25BE")), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      left: 0,
      right: 0,
      marginTop: 4,
      zIndex: 40,
      background: 'var(--bg-card)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-chip)',
      boxShadow: 'var(--shadow-menu)',
      overflow: 'hidden',
      padding: 4
    }
  }, norm.map((o, i) => {
    const on = o.value === value;
    return /*#__PURE__*/React.createElement("div", {
      key: o.value,
      onMouseEnter: () => setHoverIdx(i),
      onMouseLeave: () => setHoverIdx(-1),
      onClick: () => {
        onChange && onChange(o.value);
        setOpen(false);
      },
      style: {
        padding: '6px 8px',
        borderRadius: 4,
        fontSize: 12,
        cursor: 'pointer',
        background: on ? 'var(--tint-selected)' : hoverIdx === i ? 'var(--tint-hover)' : 'transparent',
        color: on ? 'var(--deep-teal)' : 'var(--fg-2)',
        fontFamily: on ? 'var(--font-semibold-stack)' : 'var(--font-sans)',
        fontWeight: on ? 600 : 400,
        transition: 'background-color var(--dur-1) var(--ease-out)'
      }
    }, o.label);
  })));
}
Object.assign(__ds_scope, { Dropdown });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/Dropdown.jsx", error: String((e && e.message) || e) }); }

// components/controls/PageNav.jsx
try { (() => {
/**
 * Report page navigation — chips at r8, 12px semibold slate. Hover = tint +
 * deep-teal text; active = solid teal with white text (DESIGN.md §9.5).
 */
function PageNav({
  pages,
  active,
  onChange,
  align = 'left'
}) {
  const [hover, setHover] = React.useState(null);
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 6,
      justifyContent: align === 'right' ? 'flex-end' : 'flex-start',
      flexWrap: 'wrap'
    }
  }, pages.map(p => {
    const value = typeof p === 'string' ? p : p.value;
    const label = typeof p === 'string' ? p : p.label;
    const on = value === active;
    const hot = hover === value && !on;
    return /*#__PURE__*/React.createElement("button", {
      key: value,
      onClick: () => onChange && onChange(value),
      onMouseEnter: () => setHover(value),
      onMouseLeave: () => setHover(null),
      style: {
        padding: '6px 12px',
        borderRadius: 'var(--radius-chip)',
        border: '1px solid transparent',
        fontFamily: 'var(--font-semibold-stack)',
        fontWeight: 600,
        fontSize: 12,
        cursor: 'pointer',
        background: on ? 'var(--teal)' : hot ? 'var(--tint-hover)' : 'transparent',
        color: on ? '#fff' : hot ? 'var(--deep-teal)' : 'var(--fg-2)',
        transition: 'background-color var(--dur-1) var(--ease-out), color var(--dur-1) var(--ease-out)',
        whiteSpace: 'nowrap'
      }
    }, label);
  }));
}
Object.assign(__ds_scope, { PageNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/PageNav.jsx", error: String((e && e.message) || e) }); }

// components/controls/Slicer.jsx
try { (() => {
/**
 * Slicer / filter list — lives in the fixed left column, no card box.
 * Uppercase 10px header; items 12px slate; hover text -> deep teal;
 * checked = solid teal 13px box with a white check (DESIGN.md §9.4).
 */
function Slicer({
  title,
  items,
  selected = [],
  onChange,
  multi = true
}) {
  const [hover, setHover] = React.useState(null);
  const toggle = v => {
    if (!onChange) return;
    if (!multi) return onChange([v]);
    onChange(selected.includes(v) ? selected.filter(s => s !== v) : [...selected, v]);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 7,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 10,
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--fg-1)'
    }
  }, title), items.map(it => {
    const value = typeof it === 'string' ? it : it.value;
    const label = typeof it === 'string' ? it : it.label;
    const on = selected.includes(value);
    const hot = hover === value;
    return /*#__PURE__*/React.createElement("label", {
      key: value,
      onMouseEnter: () => setHover(value),
      onMouseLeave: () => setHover(null),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        cursor: 'pointer',
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("span", {
      onClick: () => toggle(value),
      style: {
        width: 13,
        height: 13,
        flex: 'none',
        borderRadius: 3,
        border: '1px solid ' + (on ? 'var(--teal)' : 'var(--border-strong)'),
        background: on ? 'var(--teal)' : 'var(--bg-card)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: '#fff',
        fontSize: 9,
        lineHeight: 1,
        transition: 'background-color var(--dur-1) var(--ease-out), border-color var(--dur-1) var(--ease-out)'
      }
    }, on ? '✓' : ''), /*#__PURE__*/React.createElement("span", {
      onClick: () => toggle(value),
      style: {
        fontSize: 12,
        minWidth: 0,
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        fontFamily: on ? 'var(--font-semibold-stack)' : 'var(--font-sans)',
        fontWeight: on ? 600 : 400,
        color: on ? 'var(--teal)' : hot ? 'var(--deep-teal)' : 'var(--fg-2)',
        transition: 'color var(--dur-1) var(--ease-out)'
      }
    }, label), typeof it === 'object' && it.swatch && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 9,
        height: 9,
        borderRadius: 2,
        background: it.swatch,
        marginLeft: 'auto',
        flex: 'none'
      }
    }));
  }));
}
Object.assign(__ds_scope, { Slicer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/Slicer.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
const PAD = {
  xs: '0 8px',
  sm: '0 10px',
  md: '0 14px',
  lg: '0 16px'
};
const HEIGHT = {
  xs: 24,
  sm: 28,
  md: 32,
  lg: 36
};

/**
 * Primary / secondary / ghost / destructive button. Teal fill is the only
 * sanctioned solid accent; hover shifts to deep teal. Shadow/tint only — a
 * button never moves on hover.
 */
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  iconLeft = null,
  iconRight = null,
  fullWidth = false,
  type = 'button',
  onClick,
  style,
  children
}) {
  const [hover, setHover] = React.useState(false);
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    height: HEIGHT[size],
    padding: PAD[size],
    width: fullWidth ? '100%' : undefined,
    fontFamily: 'var(--font-semibold-stack)',
    fontWeight: 600,
    fontSize: size === 'xs' ? 11 : 12,
    borderRadius: 'var(--radius-chip)',
    border: '1px solid transparent',
    cursor: disabled ? 'default' : 'pointer',
    whiteSpace: 'nowrap',
    transition: 'background-color var(--dur-1) var(--ease-out), color var(--dur-1) var(--ease-out), border-color var(--dur-1) var(--ease-out)'
  };
  const on = hover && !disabled;
  const variants = {
    primary: {
      background: on ? 'var(--deep-teal)' : 'var(--teal)',
      color: '#fff'
    },
    secondary: {
      background: on ? 'var(--tint-hover)' : 'var(--bg-card)',
      color: 'var(--deep-teal)',
      borderColor: on ? 'var(--border-strong)' : 'var(--border)'
    },
    ghost: {
      background: on ? 'var(--tint-hover)' : 'transparent',
      color: on ? 'var(--deep-teal)' : 'var(--fg-2)'
    },
    destructive: {
      background: 'var(--tint-bad)',
      color: on ? 'var(--ink)' : 'var(--bad-text)'
    }
  };
  const off = disabled ? {
    background: 'transparent',
    color: 'var(--fg-disabled)',
    borderColor: 'var(--border)'
  } : variants[variant];
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...off,
      ...style
    }
  }, iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
/**
 * Visual container: opaque white, 1px hairline, radius 10, layered ink shadow.
 * Head padding 11/14, body padding 14 (DESIGN.md §9.1).
 */
function Card({
  title,
  accentTerm,
  action,
  interactive = false,
  padded = true,
  style,
  bodyStyle,
  children
}) {
  const [hover, setHover] = React.useState(false);
  const lift = interactive && hover;
  return /*#__PURE__*/React.createElement("section", {
    onMouseEnter: interactive ? () => setHover(true) : undefined,
    onMouseLeave: interactive ? () => setHover(false) : undefined,
    style: {
      background: 'var(--bg-card)',
      border: '1px solid ' + (lift ? 'var(--border-strong)' : 'var(--border)'),
      borderRadius: 'var(--radius-card)',
      boxShadow: lift ? 'var(--shadow-raised)' : 'var(--shadow-card)',
      transition: 'box-shadow var(--dur-2) var(--ease-out), border-color var(--dur-2) var(--ease-out)',
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0,
      ...style
    }
  }, title && /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 8,
      padding: '11px 14px 0 14px'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 12,
      color: 'var(--fg-1)',
      letterSpacing: 0
    }
  }, title, accentTerm && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--teal)'
    }
  }, " ", accentTerm)), action), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: padded ? 14 : 0,
      flex: 1,
      minWidth: 0,
      ...bodyStyle
    }
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/StatusPill.jsx
try { (() => {
const TONES = {
  good: {
    background: 'var(--tint-good)',
    color: 'var(--good-text)'
  },
  neutral: {
    background: 'var(--tint-neutral)',
    color: 'var(--neutral-text)'
  },
  bad: {
    background: 'var(--tint-bad)',
    color: 'var(--bad-text)'
  },
  filter: {
    background: 'var(--tint-active)',
    color: 'var(--deep-teal)'
  },
  quiet: {
    background: 'var(--bg-neutral)',
    color: 'var(--fg-2)'
  }
};

/** Status / filter pill: sentiment tint background with darkened sentiment text. */
function StatusPill({
  tone = 'quiet',
  dot = false,
  onDismiss,
  children,
  style
}) {
  const t = TONES[tone] || TONES.quiet;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '4px 12px',
      borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 11,
      lineHeight: 1.4,
      ...t,
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: 'currentColor'
    }
  }), children, onDismiss && /*#__PURE__*/React.createElement("span", {
    onClick: onDismiss,
    role: "button",
    style: {
      cursor: 'pointer',
      opacity: 0.7,
      fontSize: 10
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { StatusPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatusPill.jsx", error: String((e && e.message) || e) }); }

// components/data/BarChart.jsx
try { (() => {
const DIV = ['var(--div-afp)', 'var(--div-anc)', 'var(--div-imp)', 'var(--div-inl)', 'var(--rose)'];

/**
 * Column chart. Category gridlines off, value gridlines --bg-neutral, bars r2-3,
 * axis labels 10px slate. Colors positional by default (AFP·ANC·IMP·INL).
 */
function BarChart({
  data,
  height = 180,
  colors = DIV,
  valueFormat = v => v.toLocaleString('en-US'),
  showValues = false,
  horizontal = false,
  gridCount = 4
}) {
  const max = Math.max(...data.map(d => d.value), 1);
  const nice = Math.ceil(max / 10 ** Math.floor(Math.log10(max))) * 10 ** Math.floor(Math.log10(max));
  const [hover, setHover] = React.useState(-1);
  if (horizontal) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      }
    }, data.map((d, i) => /*#__PURE__*/React.createElement("div", {
      key: d.label,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        color: 'var(--fg-2)',
        width: 46,
        flex: 'none'
      }
    }, d.label), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 14,
        background: 'var(--bg-neutral)',
        borderRadius: 2,
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: d.value / nice * 100 + '%',
        height: '100%',
        background: d.color || colors[i % colors.length],
        borderRadius: 2
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        color: 'var(--fg-2)',
        fontVariantNumeric: 'tabular-nums',
        width: 62,
        textAlign: 'right',
        flex: 'none'
      }
    }, valueFormat(d.value)))));
  }
  const grid = Array.from({
    length: gridCount + 1
  }, (_, i) => nice / gridCount * i);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      height
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      paddingBottom: 18,
      width: 40,
      flex: 'none'
    }
  }, [...grid].reverse().map(g => /*#__PURE__*/React.createElement("span", {
    key: g,
    style: {
      fontSize: 9,
      color: 'var(--fg-2)',
      textAlign: 'right',
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1
    }
  }, valueFormat(g)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      position: 'relative',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: '0 0 18px 0'
    }
  }, grid.map((g, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: i / gridCount * 100 + '%',
      height: 1,
      background: 'var(--bg-neutral)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: '0 0 18px 0',
      display: 'flex',
      alignItems: 'flex-end',
      gap: '6%',
      padding: '0 2%'
    }
  }, data.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: d.label,
    onMouseEnter: () => setHover(i),
    onMouseLeave: () => setHover(-1),
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'flex-end',
      height: '100%'
    }
  }, showValues && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 9,
      color: 'var(--fg-2)',
      marginBottom: 3,
      fontVariantNumeric: 'tabular-nums'
    }
  }, valueFormat(d.value)), /*#__PURE__*/React.createElement("div", {
    title: d.label + ': ' + valueFormat(d.value),
    style: {
      width: '100%',
      height: d.value / nice * 100 + '%',
      background: d.color || colors[i % colors.length],
      borderRadius: '3px 3px 0 0',
      opacity: hover === -1 || hover === i ? 1 : 0.55,
      transition: 'opacity var(--dur-1) var(--ease-out)'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      display: 'flex',
      gap: '6%',
      padding: '0 2%'
    }
  }, data.map(d => /*#__PURE__*/React.createElement("span", {
    key: d.label,
    style: {
      flex: 1,
      textAlign: 'center',
      fontSize: 10,
      color: 'var(--fg-2)'
    }
  }, d.label)))));
}
Object.assign(__ds_scope, { BarChart });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/BarChart.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
const money = n => n < 0 ? '(' + Math.abs(n).toLocaleString('en-US') + ')' : n.toLocaleString('en-US');

/**
 * Matrix / table: deep-teal header band, white rows, horizontal rules only,
 * tabular right-aligned numerics, negatives red + parenthesized (DESIGN.md §9.3).
 */
function DataTable({
  columns,
  rows,
  totals,
  currency = '$',
  sortable = false,
  initialSort = null,
  onRowClick
}) {
  const [sort, setSort] = React.useState(initialSort);
  const [hover, setHover] = React.useState(-1);
  const sorted = React.useMemo(() => {
    if (!sort) return rows;
    const dir = sort.dir === 'asc' ? 1 : -1;
    return [...rows].sort((a, b) => {
      const x = a[sort.key],
        y = b[sort.key];
      if (typeof x === 'number' && typeof y === 'number') return (x - y) * dir;
      return String(x).localeCompare(String(y)) * dir;
    });
  }, [rows, sort]);
  const cell = (col, v) => {
    if (col.numeric) {
      const neg = typeof v === 'number' && v < 0;
      return /*#__PURE__*/React.createElement("span", {
        style: {
          color: neg ? 'var(--bad)' : undefined
        }
      }, typeof v === 'number' ? col.money ? currency + money(v) : money(v) : v);
    }
    return v;
  };
  const toggle = key => {
    if (!sortable) return;
    setSort(s => s && s.key === key ? {
      key,
      dir: s.dir === 'asc' ? 'desc' : 'asc'
    } : {
      key,
      dir: 'desc'
    });
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-card)',
      overflow: 'hidden',
      background: 'var(--bg-card)',
      boxShadow: 'var(--shadow-card)'
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      borderCollapse: 'collapse',
      width: '100%',
      fontVariantNumeric: 'tabular-nums lining-nums'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    onClick: () => toggle(c.key),
    style: {
      background: 'var(--deep-teal)',
      color: '#fff',
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 10.5,
      textAlign: c.numeric ? 'right' : 'left',
      padding: '9px 14px',
      whiteSpace: 'nowrap',
      width: c.width,
      cursor: sortable ? 'pointer' : 'default',
      userSelect: 'none'
    }
  }, c.label, sortable && sort && sort.key === c.key && /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: 0.8
    }
  }, sort.dir === 'asc' ? ' ▲' : ' ▼'))))), /*#__PURE__*/React.createElement("tbody", null, sorted.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    onMouseEnter: () => setHover(i),
    onMouseLeave: () => setHover(-1),
    onClick: onRowClick ? () => onRowClick(r) : undefined,
    style: {
      background: hover === i ? 'var(--tint-hover)' : 'transparent',
      cursor: onRowClick ? 'pointer' : 'default',
      transition: 'background-color var(--dur-1) var(--ease-out)'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      padding: '6px 14px',
      fontSize: 11,
      color: 'var(--fg-2)',
      textAlign: c.numeric ? 'right' : 'left',
      borderBottom: '1px solid var(--bg-neutral)',
      whiteSpace: 'nowrap',
      fontWeight: c.emphasis ? 600 : 400,
      ...(c.emphasis ? {
        color: 'var(--fg-1)'
      } : null)
    }
  }, cell(c, r[c.key]))))), totals && /*#__PURE__*/React.createElement("tr", null, columns.map((c, ci) => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      padding: '7px 14px',
      fontSize: 11,
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      color: 'var(--fg-1)',
      textAlign: c.numeric ? 'right' : 'left',
      borderTop: '1px solid var(--border)'
    }
  }, ci === 0 && !(c.key in totals) ? 'Total' : cell(c, totals[c.key])))))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/data/KpiCallout.jsx
try { (() => {
const fmt = v => typeof v === 'number' ? v.toLocaleString('en-US') : v;

/**
 * KPI callout — 30px semibold deep-teal tabular value, 11px slate label,
 * optional sentiment delta. Category accent is a 9px swatch beside the label,
 * never a tinted card fill (DESIGN.md §9.2).
 */
function KpiCallout({
  label,
  value,
  prefix = '',
  suffix = '',
  delta,
  deltaTone = 'good',
  note,
  accent,
  align = 'left',
  size = 'md'
}) {
  const fs = size === 'sm' ? 22 : size === 'lg' ? 38 : 30;
  const tone = deltaTone === 'bad' ? 'var(--bad)' : deltaTone === 'neutral' ? 'var(--neutral)' : 'var(--good)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5,
      alignItems: align === 'center' ? 'center' : 'flex-start',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, accent && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: 2,
      background: accent,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--fg-2)',
      letterSpacing: 0.1
    }
  }, label)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: fs,
      color: 'var(--deep-teal)',
      lineHeight: 1,
      fontVariantNumeric: 'tabular-nums lining-nums'
    }
  }, prefix, fmt(value), suffix), (delta || note) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 6
    }
  }, delta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-semibold-stack)',
      fontWeight: 600,
      fontSize: 11,
      color: tone,
      fontVariantNumeric: 'tabular-nums lining-nums'
    }
  }, delta), note && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: 'var(--fg-3)'
    }
  }, note)));
}
Object.assign(__ds_scope, { KpiCallout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/KpiCallout.jsx", error: String((e && e.message) || e) }); }

// components/data/LineChart.jsx
try { (() => {
const DIV = ['var(--div-afp)', 'var(--div-anc)', 'var(--div-imp)', 'var(--div-inl)'];

/**
 * Line / area chart. Weight 2.5 strokes, 2.6px dots, area fill <= 10% opacity —
 * the one sanctioned transparency, because it's a data encoding (DESIGN.md §10).
 */
function LineChart({
  series,
  labels,
  height = 180,
  colors = DIV,
  area = false,
  valueFormat = v => v.toLocaleString('en-US'),
  gridCount = 4,
  legend = true
}) {
  const all = series.flatMap(s => s.values).filter(v => v != null);
  const max = Math.max(...all, 1);
  const mag = 10 ** Math.floor(Math.log10(max));
  const nice = Math.ceil(max / mag) * mag;
  const W = 600,
    H = 200,
    padL = 6,
    padR = 6,
    padB = 4;
  const x = i => padL + i / Math.max(labels.length - 1, 1) * (W - padL - padR);
  const y = v => (1 - v / nice) * (H - padB);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      height
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      paddingBottom: 18,
      width: 42,
      flex: 'none'
    }
  }, Array.from({
    length: gridCount + 1
  }, (_, i) => nice / gridCount * (gridCount - i)).map(g => /*#__PURE__*/React.createElement("span", {
    key: g,
    style: {
      fontSize: 9,
      color: 'var(--fg-2)',
      textAlign: 'right',
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1
    }
  }, valueFormat(g)))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: '0 0 ' + W + ' ' + H,
    preserveAspectRatio: "none",
    style: {
      position: 'absolute',
      inset: '0 0 18px 0',
      width: '100%',
      height: 'calc(100% - 18px)'
    }
  }, Array.from({
    length: gridCount + 1
  }, (_, i) => /*#__PURE__*/React.createElement("line", {
    key: i,
    x1: "0",
    x2: W,
    y1: y(nice / gridCount * i),
    y2: y(nice / gridCount * i),
    stroke: "var(--bg-neutral)",
    strokeWidth: "1",
    vectorEffect: "non-scaling-stroke"
  })), series.map((s, si) => {
    const c = s.color || colors[si % colors.length];
    // Missing values BREAK the line — never coerce a not-yet-closed month to 0.
    const points = s.values.map((v, i) => ({
      v,
      i
    })).filter(p => p.v != null);
    const pts = points.map(p => x(p.i) + ',' + y(p.v)).join(' ');
    const first = points[0],
      last = points[points.length - 1];
    return /*#__PURE__*/React.createElement("g", {
      key: s.label
    }, area && points.length > 1 && /*#__PURE__*/React.createElement("polygon", {
      points: x(first.i) + ',' + y(0) + ' ' + pts + ' ' + x(last.i) + ',' + y(0),
      fill: c,
      opacity: "0.1"
    }), /*#__PURE__*/React.createElement("polyline", {
      points: pts,
      fill: "none",
      stroke: c,
      strokeWidth: "2.5",
      strokeLinejoin: "round",
      strokeLinecap: "round",
      vectorEffect: "non-scaling-stroke"
    }), points.map(p => /*#__PURE__*/React.createElement("circle", {
      key: p.i,
      cx: x(p.i),
      cy: y(p.v),
      r: "2.6",
      fill: c,
      vectorEffect: "non-scaling-stroke"
    })));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, labels.map(l => /*#__PURE__*/React.createElement("span", {
    key: l,
    style: {
      fontSize: 10,
      color: 'var(--fg-2)'
    }
  }, l))))), legend && series.length > 1 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      marginTop: 10,
      paddingLeft: 48
    }
  }, series.map((s, si) => /*#__PURE__*/React.createElement("span", {
    key: s.label,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontSize: 10,
      color: 'var(--fg-2)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: 2,
      background: s.color || colors[si % colors.length]
    }
  }), s.label))));
}
Object.assign(__ds_scope, { LineChart });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/LineChart.jsx", error: String((e && e.message) || e) }); }

// ui_kits/powerbi_report/ArAging.jsx
try { (() => {
const {
  Card,
  KpiCallout,
  DataTable,
  BarChart
} = window.RCMIndustriesDesignSystem_047627;
const BUCKETS = [{
  key: 'cur',
  label: 'Current',
  color: 'var(--sev-current)'
}, {
  key: 'a',
  label: '1–30',
  color: 'var(--sev-1-30)'
}, {
  key: 'b',
  label: '31–60',
  color: 'var(--sev-31-60)'
}, {
  key: 'c',
  label: '61–90',
  color: 'var(--sev-61-90)'
}, {
  key: 'e',
  label: '91–120',
  color: 'var(--sev-91-120)'
}, {
  key: 'g',
  label: '121+',
  color: 'var(--sev-121)'
}];
function ArAging({
  sel
}) {
  const rows = window.RCM_DATA.aging.filter(r => sel.includes(r.d));
  const sum = k => rows.reduce((s, r) => s + r[k], 0);
  const total = BUCKETS.reduce((s, b) => s + sum(b.key), 0);
  const pastDue = total - sum('cur');
  const totals = {
    d: 'Total'
  };
  BUCKETS.forEach(b => {
    totals[b.key] = sum(b.key);
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    style: {
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Total AR",
    value: total,
    prefix: "$"
  }), /*#__PURE__*/React.createElement(KpiCallout, {
    size: "sm",
    label: "Past due",
    value: pastDue,
    prefix: "$",
    delta: "\u25B2 8.4%",
    deltaTone: "bad",
    note: "vs. prior month"
  }), /*#__PURE__*/React.createElement(KpiCallout, {
    size: "sm",
    label: "Past due %",
    value: (pastDue / total * 100).toFixed(1),
    suffix: "%"
  }), /*#__PURE__*/React.createElement(KpiCallout, {
    size: "sm",
    label: "121+ exposure",
    value: sum('g'),
    prefix: "$",
    accent: "var(--sev-121)"
  }), /*#__PURE__*/React.createElement(KpiCallout, {
    size: "sm",
    label: "Avg days outstanding",
    value: "41",
    delta: "\u25BC 3 days",
    note: "improving"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.15fr 1fr',
      gap: 12,
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Aging",
    accentTerm: "by bucket"
  }, /*#__PURE__*/React.createElement(BarChart, {
    height: 185,
    valueFormat: window.millions,
    showValues: false,
    data: BUCKETS.map(b => ({
      label: b.label,
      value: sum(b.key),
      color: b.color
    }))
  })), /*#__PURE__*/React.createElement(Card, {
    title: "Past due by",
    accentTerm: "division"
  }, /*#__PURE__*/React.createElement(BarChart, {
    horizontal: true,
    valueFormat: v => '$' + Math.round(v / 1000).toLocaleString('en-US') + 'K',
    data: rows.map(r => ({
      label: r.d,
      value: BUCKETS.slice(1).reduce((s, b) => s + Math.max(r[b.key], 0), 0)
    }))
  }))), /*#__PURE__*/React.createElement(Card, {
    title: "Aging",
    accentTerm: "matrix",
    padded: false,
    style: {
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 14px 14px'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    sortable: true,
    initialSort: {
      key: 'cur',
      dir: 'desc'
    },
    columns: [{
      key: 'd',
      label: 'Division',
      emphasis: true,
      width: 110
    }, ...BUCKETS.map(b => ({
      key: b.key,
      label: b.label,
      numeric: true,
      money: true
    }))],
    rows: rows,
    totals: totals
  }))));
}
Object.assign(window, {
  ArAging
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/powerbi_report/ArAging.jsx", error: String((e && e.message) || e) }); }

// ui_kits/powerbi_report/ExecutiveSummary.jsx
try { (() => {
const {
  Card,
  KpiCallout,
  DataTable,
  BarChart,
  LineChart,
  StatusPill
} = window.RCMIndustriesDesignSystem_047627;
function ExecutiveSummary({
  sel
}) {
  const D = window.RCM_DATA;
  const active = D.divisions.filter(d => sel.includes(d.code));
  const total = active.reduce((s, d) => s + D.backlog[d.code], 0);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    style: {
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Open order backlog",
    value: total,
    prefix: "$",
    delta: "\u25BC 2.1%",
    deltaTone: "bad",
    note: "vs. prior month"
  }), active.map(d => /*#__PURE__*/React.createElement(KpiCallout, {
    key: d.code,
    size: "sm",
    label: d.code,
    value: D.backlog[d.code],
    prefix: "$",
    accent: d.color
  })), /*#__PURE__*/React.createElement(KpiCallout, {
    size: "sm",
    label: "On-time delivery",
    value: "98.4",
    suffix: "%",
    delta: "\u25B2 0.6 pt",
    note: "rolling 30 days"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12,
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Backlog by",
    accentTerm: "division",
    bodyStyle: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(BarChart, {
    height: 185,
    valueFormat: window.millions,
    data: active.map(d => ({
      label: d.code,
      value: D.backlog[d.code],
      color: d.color
    }))
  })), /*#__PURE__*/React.createElement(Card, {
    title: "Forecast vs.",
    accentTerm: "actual"
  }, /*#__PURE__*/React.createElement(LineChart, {
    area: true,
    height: 175,
    labels: D.months,
    valueFormat: window.millions,
    series: [{
      label: 'Forecast',
      values: D.forecast
    }, {
      label: 'Actual',
      values: D.actual
    }]
  }))), /*#__PURE__*/React.createElement(Card, {
    title: "Backlog",
    accentTerm: "detail",
    padded: false,
    style: {
      flex: 'none'
    },
    action: /*#__PURE__*/React.createElement(StatusPill, {
      tone: "filter"
    }, sel.length, " of 4 divisions")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 14px 14px'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'd',
      label: 'Division',
      emphasis: true,
      width: 110
    }, {
      key: 'cur',
      label: 'Current',
      numeric: true,
      money: true
    }, {
      key: 'a',
      label: '1–30',
      numeric: true,
      money: true
    }, {
      key: 'b',
      label: '31–60',
      numeric: true,
      money: true
    }, {
      key: 'c',
      label: '61–90',
      numeric: true,
      money: true
    }],
    rows: D.aging.filter(r => sel.includes(r.d))
  }))));
}
Object.assign(window, {
  ExecutiveSummary
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/powerbi_report/ExecutiveSummary.jsx", error: String((e && e.message) || e) }); }

// ui_kits/powerbi_report/OpenOrders.jsx
try { (() => {
const {
  Card,
  KpiCallout,
  DataTable,
  StatusPill,
  BarChart
} = window.RCMIndustriesDesignSystem_047627;
function OpenOrders({
  sel
}) {
  const D = window.RCM_DATA;
  const rows = D.orders.filter(o => sel.includes(o.div));
  const value = rows.reduce((s, o) => s + o.value, 0);
  const qty = rows.reduce((s, o) => s + o.qty, 0);
  const late = rows.filter(o => o.status === 'Past due');
  const byDiv = D.divisions.filter(d => sel.includes(d.code)).map(d => ({
    label: d.code,
    color: d.color,
    value: rows.filter(o => o.div === d.code).reduce((s, o) => s + o.value, 0)
  }));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr 1fr 1fr',
      gap: 12,
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Open order value",
    value: value,
    prefix: "$",
    size: "sm"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Open lines",
    value: rows.length,
    size: "sm"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Units committed",
    value: qty,
    size: "sm"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Past due lines",
    value: late.length,
    size: "sm",
    delta: late.length ? '▲ ' + late.length : '▼ 0',
    deltaTone: late.length ? 'bad' : 'good',
    note: "expedite review"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.6fr 1fr',
      gap: 12,
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Open orders",
    accentTerm: "by line",
    padded: false,
    action: /*#__PURE__*/React.createElement(StatusPill, {
      tone: "filter"
    }, rows.length, " lines")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 14px 14px'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    sortable: true,
    columns: [{
      key: 'po',
      label: 'PO',
      emphasis: true,
      width: 100
    }, {
      key: 'cust',
      label: 'Customer'
    }, {
      key: 'div',
      label: 'Division',
      width: 70
    }, {
      key: 'part',
      label: 'Part'
    }, {
      key: 'qty',
      label: 'Qty',
      numeric: true
    }, {
      key: 'value',
      label: 'Value',
      numeric: true,
      money: true
    }, {
      key: 'due',
      label: 'Due',
      width: 74
    }],
    rows: rows,
    totals: {
      po: 'Total',
      qty,
      value
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 12
    }
  }, rows.slice(0, 4).map(o => /*#__PURE__*/React.createElement(StatusPill, {
    key: o.po,
    dot: true,
    tone: o.status === 'Past due' ? 'bad' : o.status === 'Watch' ? 'neutral' : 'good'
  }, o.po, " \xB7 ", o.status))))), /*#__PURE__*/React.createElement(Card, {
    title: "Value by",
    accentTerm: "division"
  }, /*#__PURE__*/React.createElement(BarChart, {
    height: 190,
    data: byDiv,
    valueFormat: v => '$' + Math.round(v / 1000).toLocaleString('en-US') + 'K'
  }))));
}
Object.assign(window, {
  OpenOrders
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/powerbi_report/OpenOrders.jsx", error: String((e && e.message) || e) }); }

// ui_kits/powerbi_report/ReportFrame.jsx
try { (() => {
const {
  Slicer,
  PageNav,
  Dropdown
} = window.RCMIndustriesDesignSystem_047627;
const money = v => '$' + Math.round(v).toLocaleString('en-US');
const millions = v => '$' + (v / 1e6).toFixed(1) + 'M';

/** The fixed report canvas: 1280×720, slicer rail at x=10 w=150, content seam
 *  at x=170, logo box 70×60 top-right, page title at the seam. */
function ReportCanvas({
  title,
  accentTerm,
  pages,
  page,
  onPage,
  slicers,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: 1280,
      height: 720,
      background: 'var(--bg-page)',
      fontFamily: 'var(--font-sans)',
      overflow: 'hidden',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/Logo_RCM_Teal.png",
    alt: "RCM Industries",
    style: {
      position: 'absolute',
      right: 20,
      top: 10,
      width: 70,
      height: 60,
      objectFit: 'contain'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 170,
      top: 16,
      right: 110
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 20,
      letterSpacing: 'var(--tracking-tight)'
    }
  }, title, accentTerm && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--teal)'
    }
  }, " ", accentTerm)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(PageNav, {
    pages: pages,
    active: page,
    onChange: onPage
  }))), /*#__PURE__*/React.createElement("aside", {
    style: {
      position: 'absolute',
      left: 10,
      top: 16,
      width: 150,
      bottom: 14,
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, slicers), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 170,
      top: 88,
      right: 20,
      bottom: 14
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 170,
      bottom: -2,
      fontSize: 9,
      color: 'var(--fg-3)'
    }
  }, "Illustrative data \xB7 RCM Industries \xB7 Modern Teal v2.0"));
}

/** The shared slicer rail — division, plant, period. */
function SlicerRail({
  divisions,
  sel,
  onSel,
  plant,
  onPlant,
  period,
  onPeriod
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Slicer, {
    title: "Division",
    selected: sel,
    onChange: onSel,
    items: divisions.map(d => ({
      value: d.code,
      label: d.code,
      swatch: d.color
    }))
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Plant",
    options: window.RCM_DATA.plants,
    value: plant,
    onChange: onPlant,
    width: 150,
    size: "sm"
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Period",
    options: window.RCM_DATA.periods,
    value: period,
    onChange: onPeriod,
    width: 150,
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      fontSize: 9,
      color: 'var(--fg-3)',
      lineHeight: 1.5
    }
  }, "Filters apply to every visual on the page."));
}
Object.assign(window, {
  ReportCanvas,
  SlicerRail,
  money,
  millions
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/powerbi_report/ReportFrame.jsx", error: String((e && e.message) || e) }); }

// ui_kits/powerbi_report/SixMonthForecast.jsx
try { (() => {
const {
  Card,
  KpiCallout,
  DataTable,
  LineChart
} = window.RCMIndustriesDesignSystem_047627;
function SixMonthForecast() {
  const D = window.RCM_DATA;
  const rows = D.months.map((m, i) => ({
    m,
    f: D.forecast[i],
    a: D.actual[i] == null ? '—' : D.actual[i],
    v: D.actual[i] == null ? '—' : D.actual[i] - D.forecast[i]
  }));
  const closed = D.actual.filter(v => v != null);
  const attain = closed.reduce((s, v) => s + v, 0) / D.forecast.slice(0, closed.length).reduce((s, v) => s + v, 0) * 100;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    style: {
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "6 month forecast",
    value: D.forecast.reduce((s, v) => s + v, 0),
    prefix: "$"
  }), /*#__PURE__*/React.createElement(KpiCallout, {
    size: "sm",
    label: "Closed months actual",
    value: closed.reduce((s, v) => s + v, 0),
    prefix: "$"
  }), /*#__PURE__*/React.createElement(KpiCallout, {
    size: "sm",
    label: "Forecast attainment",
    value: attain.toFixed(1),
    suffix: "%",
    delta: attain >= 100 ? '▲ on plan' : '▼ under plan',
    deltaTone: attain >= 100 ? 'good' : 'neutral'
  }), /*#__PURE__*/React.createElement(KpiCallout, {
    size: "sm",
    label: "Open months",
    value: D.actual.filter(v => v == null).length,
    note: "not yet closed"
  }))), /*#__PURE__*/React.createElement(Card, {
    title: "Forecast vs.",
    accentTerm: "actual",
    style: {
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(LineChart, {
    area: true,
    height: 200,
    labels: D.months,
    valueFormat: window.millions,
    series: [{
      label: 'Forecast',
      values: D.forecast
    }, {
      label: 'Actual',
      values: D.actual
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.3fr 1fr',
      gap: 12,
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Monthly",
    accentTerm: "variance",
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 14px 14px'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'm',
      label: 'Month',
      emphasis: true,
      width: 90
    }, {
      key: 'f',
      label: 'Forecast',
      numeric: true,
      money: true
    }, {
      key: 'a',
      label: 'Actual',
      numeric: true,
      money: true
    }, {
      key: 'v',
      label: 'Variance',
      numeric: true,
      money: true
    }],
    rows: rows
  }))), /*#__PURE__*/React.createElement(Card, {
    title: "Shipments",
    accentTerm: "AFP vs ANC"
  }, /*#__PURE__*/React.createElement(LineChart, {
    height: 118,
    labels: D.months,
    valueFormat: v => '$' + v.toFixed(1) + 'M',
    series: [{
      label: 'AFP',
      values: D.shipments.AFP,
      color: 'var(--div-afp)'
    }, {
      label: 'ANC',
      values: D.shipments.ANC,
      color: 'var(--div-anc)'
    }]
  }))));
}
Object.assign(window, {
  SixMonthForecast
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/powerbi_report/SixMonthForecast.jsx", error: String((e && e.message) || e) }); }

// ui_kits/powerbi_report/data.js
try { (() => {
// Illustrative figures shaped like RCM's real report measures. Not actual data.
window.RCM_DATA = {
  divisions: [{
    code: 'AFP',
    color: 'var(--div-afp)'
  }, {
    code: 'ANC',
    color: 'var(--div-anc)'
  }, {
    code: 'IMP',
    color: 'var(--div-imp)'
  }, {
    code: 'INL',
    color: 'var(--div-inl)'
  }],
  plants: ['All plants', 'Cicero', 'Elgin', 'Belvidere'],
  periods: ['FY26 Q1', 'FY25 Q4', 'FY25 Q3'],
  backlog: {
    AFP: 4266042,
    ANC: 4154391,
    IMP: 2880517,
    INL: 1920684
  },
  aging: [{
    d: 'AFP',
    cur: 4266042,
    a: 799040,
    b: -7380,
    c: 12400,
    e: 4180,
    g: 1120
  }, {
    d: 'ANC',
    cur: 4154391,
    a: 96861,
    b: 1697,
    c: 0,
    e: 0,
    g: 480
  }, {
    d: 'IMP',
    cur: 2880517,
    a: 402118,
    b: 58204,
    c: -1205,
    e: 9640,
    g: 2310
  }, {
    d: 'INL',
    cur: 1920684,
    a: 210553,
    b: 14902,
    c: 3310,
    e: 1870,
    g: 0
  }],
  orders: [{
    po: 'PO-118402',
    cust: 'Meritor',
    div: 'AFP',
    part: '4-CYL HOUSING',
    qty: 12400,
    value: 421880,
    due: '08/14/26',
    status: 'On target'
  }, {
    po: 'PO-118417',
    cust: 'Deere',
    div: 'ANC',
    part: 'PUMP BODY 2B',
    qty: 8600,
    value: 388140,
    due: '08/19/26',
    status: 'Watch'
  }, {
    po: 'PO-118423',
    cust: 'Caterpillar',
    div: 'IMP',
    part: 'VALVE COVER',
    qty: 21500,
    value: 512300,
    due: '08/21/26',
    status: 'On target'
  }, {
    po: 'PO-118440',
    cust: 'Navistar',
    div: 'INL',
    part: 'BRACKET LH',
    qty: 4200,
    value: 96420,
    due: '08/03/26',
    status: 'Past due'
  }, {
    po: 'PO-118455',
    cust: 'Meritor',
    div: 'AFP',
    part: 'END CAP 40MM',
    qty: 33800,
    value: 274960,
    due: '09/02/26',
    status: 'On target'
  }, {
    po: 'PO-118461',
    cust: 'Bosch',
    div: 'ANC',
    part: 'MANIFOLD S3',
    qty: 6100,
    value: 208700,
    due: '09/09/26',
    status: 'Watch'
  }, {
    po: 'PO-118472',
    cust: 'Deere',
    div: 'IMP',
    part: 'HOUSING 6C',
    qty: 15200,
    value: 456000,
    due: '09/15/26',
    status: 'On target'
  }],
  months: ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan'],
  forecast: [12100000, 12640000, 13020000, 13440000, 13880000, 14220000],
  actual: [11840000, 12410000, 13180000, 13120000, 13210000, null],
  shipments: {
    AFP: [3.9, 4.1, 4.3, 4.2, 4.4, 4.5],
    ANC: [3.6, 3.8, 3.9, 4.0, 4.1, 4.2]
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/powerbi_report/data.js", error: String((e && e.message) || e) }); }

// ui_kits/rayfin_app/ArDashboard.jsx
try { (() => {
const {
  Card,
  KpiCallout,
  DataTable,
  BarChart,
  LineChart,
  StatusPill,
  Button
} = window.RCMIndustriesDesignSystem_047627;
const K = v => '$' + Math.round(v / 1000).toLocaleString('en-US') + 'K';
const M = v => '$' + (v / 1e6).toFixed(1) + 'M';
function ArDashboard({
  rows
}) {
  const D = window.RAYFIN_DATA;
  const total = rows.reduce((s, r) => s + r.total, 0);
  const past = rows.reduce((s, r) => s + r.pastdue, 0);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Total AR",
    value: total,
    prefix: "$",
    size: "sm"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Past due",
    value: past,
    prefix: "$",
    size: "sm",
    delta: "\u25B2 8.4%",
    deltaTone: "bad",
    note: "vs. prior month"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Past due %",
    value: (past / total * 100).toFixed(1),
    suffix: "%",
    size: "sm"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Avg days outstanding",
    value: "41",
    size: "sm",
    delta: "\u25BC 3 days",
    note: "improving"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "AR and",
    accentTerm: "past due",
    bodyStyle: {
      paddingTop: 10
    }
  }, /*#__PURE__*/React.createElement(LineChart, {
    area: true,
    labels: D.months,
    valueFormat: M,
    height: 190,
    series: [{
      label: 'Total AR',
      values: D.ar
    }, {
      label: 'Past due',
      values: D.pastdue
    }]
  })), /*#__PURE__*/React.createElement(Card, {
    title: "Past due by",
    accentTerm: "customer",
    bodyStyle: {
      paddingTop: 14
    }
  }, /*#__PURE__*/React.createElement(BarChart, {
    horizontal: true,
    valueFormat: K,
    data: [...rows].sort((a, b) => b.pastdue - a.pastdue).slice(0, 6).map(r => ({
      label: r.cust.slice(0, 7),
      value: r.pastdue
    }))
  }))), /*#__PURE__*/React.createElement(Card, {
    title: "Open",
    accentTerm: "holds",
    padded: false,
    action: /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm"
    }, "Export")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 14px 14px'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    columns: [{
      key: 'po',
      label: 'PO',
      emphasis: true,
      width: 110
    }, {
      key: 'cust',
      label: 'Customer',
      width: 130
    }, {
      key: 'reason',
      label: 'Reason'
    }, {
      key: 'owner',
      label: 'Owner',
      width: 110
    }, {
      key: 'age',
      label: 'Days open',
      numeric: true,
      width: 90
    }],
    rows: D.holds
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(StatusPill, {
    tone: "bad",
    dot: true
  }, "1 credit hold"), /*#__PURE__*/React.createElement(StatusPill, {
    tone: "neutral",
    dot: true
  }, "2 awaiting customer")))));
}
Object.assign(window, {
  ArDashboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rayfin_app/ArDashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rayfin_app/ArReview.jsx
try { (() => {
const {
  Card,
  DataTable,
  StatusPill,
  Button,
  Dropdown
} = window.RCMIndustriesDesignSystem_047627;
function ArReview({
  rows,
  onOpen
}) {
  const [bucket, setBucket] = React.useState('All buckets');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Customer",
    accentTerm: "aging",
    padded: false,
    action: /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement(Dropdown, {
      options: ['All buckets', 'Current', '1–30', '31–60', '61–90', '121+'],
      value: bucket,
      onChange: setBucket,
      width: 130,
      size: "sm"
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm"
    }, "Send statements"), /*#__PURE__*/React.createElement(Button, {
      size: "sm"
    }, "Place hold"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 14px 14px'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    sortable: true,
    initialSort: {
      key: 'pastdue',
      dir: 'desc'
    },
    onRowClick: onOpen,
    columns: [{
      key: 'cust',
      label: 'Customer',
      emphasis: true,
      width: 150
    }, {
      key: 'div',
      label: 'Division',
      width: 90
    }, {
      key: 'total',
      label: 'Total AR',
      numeric: true,
      money: true
    }, {
      key: 'current',
      label: 'Current',
      numeric: true,
      money: true
    }, {
      key: 'pastdue',
      label: 'Past due',
      numeric: true,
      money: true
    }, {
      key: 'days',
      label: 'Avg days',
      numeric: true,
      width: 90
    }, {
      key: 'status',
      label: 'Status',
      width: 110
    }],
    rows: rows,
    totals: {
      cust: 'Total',
      total: rows.reduce((s, r) => s + r.total, 0),
      current: rows.reduce((s, r) => s + r.current, 0),
      pastdue: rows.reduce((s, r) => s + r.pastdue, 0)
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      display: 'flex',
      gap: 8,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--fg-3)'
    }
  }, "Click a row to open the customer."), /*#__PURE__*/React.createElement(StatusPill, {
    tone: "filter"
  }, rows.length, " customers")))));
}
Object.assign(window, {
  ArReview
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rayfin_app/ArReview.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rayfin_app/CustomerDetail.jsx
try { (() => {
const {
  Card,
  KpiCallout,
  DataTable,
  BarChart,
  StatusPill,
  Button
} = window.RCMIndustriesDesignSystem_047627;
const BUCKETS = [{
  label: 'Current',
  color: 'var(--sev-current)',
  share: 0.62
}, {
  label: '1–30',
  color: 'var(--sev-1-30)',
  share: 0.18
}, {
  label: '31–60',
  color: 'var(--sev-31-60)',
  share: 0.09
}, {
  label: '61–90',
  color: 'var(--sev-61-90)',
  share: 0.06
}, {
  label: '91–120',
  color: 'var(--sev-91-120)',
  share: 0.03
}, {
  label: '121+',
  color: 'var(--sev-121)',
  share: 0.02
}];
function CustomerDetail({
  row,
  onBack
}) {
  const tone = row.status === 'Past due' ? 'bad' : row.status === 'Watch' ? 'neutral' : 'good';
  const invoices = [{
    inv: 'INV-40218',
    date: '06/12/26',
    due: '07/12/26',
    amt: Math.round(row.total * 0.34),
    bucket: '1–30'
  }, {
    inv: 'INV-40265',
    date: '06/28/26',
    due: '07/28/26',
    amt: Math.round(row.total * 0.28),
    bucket: 'Current'
  }, {
    inv: 'INV-40301',
    date: '07/09/26',
    due: '08/09/26',
    amt: Math.round(row.total * 0.22),
    bucket: 'Current'
  }, {
    inv: 'INV-39944',
    date: '04/02/26',
    due: '05/02/26',
    amt: Math.round(row.total * 0.11),
    bucket: '61–90'
  }, {
    inv: 'INV-39810',
    date: '02/19/26',
    due: '03/19/26',
    amt: -Math.round(row.total * 0.01),
    bucket: '121+'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: onBack
  }, "\u2190 All customers"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 14
    }
  }, row.cust), /*#__PURE__*/React.createElement(StatusPill, {
    tone: tone,
    dot: true
  }, row.status), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--fg-3)'
    }
  }, "Division ", row.div), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm"
  }, "Statement"), /*#__PURE__*/React.createElement(Button, {
    variant: "destructive",
    size: "sm"
  }, "Place credit hold"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Total AR",
    value: row.total,
    prefix: "$",
    size: "sm"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Current",
    value: row.current,
    prefix: "$",
    size: "sm"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Past due",
    value: row.pastdue,
    prefix: "$",
    size: "sm",
    delta: row.pastdue ? '▲ open' : '▼ clear',
    deltaTone: row.pastdue ? 'bad' : 'good'
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KpiCallout, {
    label: "Avg days outstanding",
    value: row.days,
    size: "sm"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1.4fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: "Aging",
    accentTerm: "mix",
    bodyStyle: {
      paddingTop: 14
    }
  }, /*#__PURE__*/React.createElement(BarChart, {
    horizontal: true,
    valueFormat: v => '$' + Math.round(v / 1000).toLocaleString('en-US') + 'K',
    data: BUCKETS.map(b => ({
      label: b.label,
      value: Math.round(row.total * b.share),
      color: b.color
    }))
  })), /*#__PURE__*/React.createElement(Card, {
    title: "Open",
    accentTerm: "invoices",
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 14px 14px'
    }
  }, /*#__PURE__*/React.createElement(DataTable, {
    sortable: true,
    columns: [{
      key: 'inv',
      label: 'Invoice',
      emphasis: true,
      width: 120
    }, {
      key: 'date',
      label: 'Date',
      width: 90
    }, {
      key: 'due',
      label: 'Due',
      width: 90
    }, {
      key: 'bucket',
      label: 'Bucket',
      width: 90
    }, {
      key: 'amt',
      label: 'Amount',
      numeric: true,
      money: true
    }],
    rows: invoices,
    totals: {
      inv: 'Total',
      amt: invoices.reduce((s, i) => s + i.amt, 0)
    }
  })))));
}
Object.assign(window, {
  CustomerDetail
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rayfin_app/CustomerDetail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/rayfin_app/data.js
try { (() => {
// Illustrative figures shaped like an RCM Rayfin app's data. Not real data.
window.RAYFIN_DATA = {
  customers: [{
    cust: 'Meritor',
    div: 'AFP',
    total: 1281402,
    current: 986420,
    pastdue: 294982,
    days: 38,
    status: 'Watch'
  }, {
    cust: 'Deere',
    div: 'ANC',
    total: 942188,
    current: 942188,
    pastdue: 0,
    days: 24,
    status: 'On target'
  }, {
    cust: 'Caterpillar',
    div: 'IMP',
    total: 1512300,
    current: 1401220,
    pastdue: 111080,
    days: 31,
    status: 'On target'
  }, {
    cust: 'Navistar',
    div: 'INL',
    total: 296420,
    current: 88110,
    pastdue: 208310,
    days: 74,
    status: 'Past due'
  }, {
    cust: 'Bosch',
    div: 'ANC',
    total: 508700,
    current: 462100,
    pastdue: 46600,
    days: 29,
    status: 'On target'
  }, {
    cust: 'Cummins',
    div: 'AFP',
    total: 733940,
    current: 611200,
    pastdue: 122740,
    days: 44,
    status: 'Watch'
  }],
  holds: [{
    po: 'PO-118440',
    cust: 'Navistar',
    reason: 'Credit hold — 121+ balance',
    owner: 'A. Vela',
    age: 12
  }, {
    po: 'PO-118417',
    cust: 'Deere',
    reason: 'Price discrepancy on line 3',
    owner: 'M. Rios',
    age: 4
  }, {
    po: 'PO-118461',
    cust: 'Bosch',
    reason: 'Awaiting revised PO',
    owner: 'E. Reece',
    age: 2
  }],
  months: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
  ar: [11.9e6, 12.3e6, 12.1e6, 12.8e6, 13.0e6, 13.2e6],
  pastdue: [0.9e6, 1.1e6, 1.0e6, 1.2e6, 1.3e6, 1.36e6]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/rayfin_app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.AppShell = __ds_scope.AppShell;

__ds_ns.AuthCard = __ds_scope.AuthCard;

__ds_ns.Dropdown = __ds_scope.Dropdown;

__ds_ns.PageNav = __ds_scope.PageNav;

__ds_ns.Slicer = __ds_scope.Slicer;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.StatusPill = __ds_scope.StatusPill;

__ds_ns.BarChart = __ds_scope.BarChart;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.KpiCallout = __ds_scope.KpiCallout;

__ds_ns.LineChart = __ds_scope.LineChart;

})();
