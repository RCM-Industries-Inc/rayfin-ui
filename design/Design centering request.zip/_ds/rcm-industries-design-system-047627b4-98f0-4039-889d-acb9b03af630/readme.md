# RCM Industries — Design System

**Modern Teal v2.0 · July 2026**
A cross-medium brand and design foundation: Power BI reports, Word documents,
Excel workbooks, PowerPoint decks, Rayfin web applications, and any other
branded RCM artifact.

> **New here?** Read [§1](#1-company--product-context) and
> [`APPLICABILITY.md`](APPLICABILITY.md), then open the
> [Power BI report kit](ui_kits/powerbi_report/) and the
> [Rayfin app kit](ui_kits/rayfin_app/). The full file index is in
> [§8](#8-index--whats-in-this-repo).

---

## 1. Company & product context

RCM Industries is a **die-cast manufacturing company**. Its reporting and
internal applications track production and financial health across four
divisions — **AFP, ANC, IMP, INL** — and several plants (Cicero, Elgin,
Belvidere). The design language exists to serve **data**: calm, light,
monochrome-teal, quietly confident. It gets out of the way so the numbers speak.

There is **one theme — Modern Teal**: light, editorial, fully opaque. White cards
on off-white, hairline borders, layered ink shadows. The former glassmorphic
*Teal Glass* variant is **retired**; every surface is opaque, and translucency,
backdrop blur, and gradient backdrops must not be reintroduced.

### Surfaces represented here

| Surface | What it is | Kit |
|---|---|---|
| **Power BI reports** | The primary medium. A fixed 1280×720 canvas, slicer rail, KPI row, matrices, charts. Operational, executive, and print reports all share one theme. | [`ui_kits/powerbi_report/`](ui_kits/powerbi_report/) |
| **Rayfin web applications** | Internal React/Vite apps on Microsoft Fabric — AR Review, Production Planning, Headcount Report, Daily Dashboard, Insight Index. Every one wears the same shell and sign-in. | [`ui_kits/rayfin_app/`](ui_kits/rayfin_app/) |
| **Office artifacts** | Word, Excel, PowerPoint. They inherit the palette, logo rules, typography, and voice; each medium's own template owns layout. | — (no template was supplied) |

### Sources this system was built from

Nothing here was invented. Values were read from:

- **[`EreeceRCM/Design-System`](https://github.com/EreeceRCM/Design-System)** (branch `main`) — the attached
  brand repo. `DESIGN.md` (canonical surface / elevation / state / motion /
  component recipes), `README.md` (palette, type scale, voice, layout), `APPLICABILITY.md`,
  `colors_and_type.css`, `themes/RCM_Industries_Modern_Teal.json`, `assets/` logos, and its
  `preview/` specimen cards. A personal copy of
  [`RCM-Industries-Inc/Design-System`](https://github.com/RCM-Industries-Inc/Design-System).
- **[`RCM-Industries-Inc/rayfin-ui`](https://github.com/RCM-Industries-Inc/rayfin-ui)** (branch `main`) — the
  **web implementation authority** named by that repo. `src/main.css` (semantic web
  tokens + the opaque dark theme), `docs/FOUNDATION.md`, and
  `src/components/rcm/{app-shell,auth-page,data-table}.tsx`, which the
  `AppShell` / `AuthCard` components here recreate.
- **[`RCM-Industries-Inc/Rayfin_Template`](https://github.com/RCM-Industries-Inc/Rayfin_Template)** — the app
  scaffold. Referenced, not read; start new Rayfin apps there, not from this repo.

Explore those repositories directly for anything this system abstracts —
especially `rayfin-ui`, which owns web component APIs, accessibility, keyboard
behavior, and dark mode. Design work grounded in that source will be better than
work grounded in this summary. Access is private to RCM; if you can't open them,
treat [`DESIGN.md`](DESIGN.md) here as authoritative.

**Precedence:** [`DESIGN.md`](DESIGN.md) wins for reports and branded artifacts.
`rayfin-ui` wins for web application behavior. This readme is supporting context.

---

## 2. Design principles

1. **The data carries the visual.** Strip chart junk. Whitespace is a feature.
2. **One restrained palette.** Teal does the work; other hues only keep
   categories apart.
3. **Calm typography.** Muted slate, generous spacing, clear hierarchy — never
   pure-black-on-white glare.
4. **Floating cards, not heavy boxes.** *Present enough to group, quiet enough to
   recede.*
5. **Consistency across pages and tools.** Same geometry everywhere; apply the
   theme, don't restyle per visual.

---

## 3. Content fundamentals

We write like **engineers documenting for engineers: precise, operational,
lightly opinionated.** Not marketing copy. No hype, no adjectives doing a
number's job.

- **Person.** "We" for shared conventions ("We write like engineers…"); direct
  "you" for instructions ("Apply the theme JSON first"). Never "I". Rules are
  stated as bare imperatives: *"Pick the variant that contrasts with its
  background."*
- **Casing.** Sentence case for prose and UI labels (`Past due lines`,
  `Avg days outstanding`). Report and page names are **Title Case,
  purpose-first**: `Open Orders`, `6 Month Forecast`, `Executive Summary`. Code
  identifiers are PascalCase with no spaces (`OrdersAndSales`). Measures read
  naturally (`Open Order Backlog`). Slicer headers are the only ALL-CAPS text
  (10px, `+1.2px` tracking).
- **Length.** Labels are 1–3 words. A KPI label never wraps. Card titles are a
  noun phrase, not a sentence: `Backlog by division`, not `Here's the backlog`.
- **Emphasis.** **Bold** the operative term; `code font` for paths, hex values,
  and commands. **One** term in a title may be accent teal — the subject, never a
  random word: `Open Order **Backlog**`.
- **Numbers.** Thousands separators always. Negatives are red **and**
  parenthesized: `($7,380)` — both signals, always. Percentages one decimal
  (`98.4%`). Aging buckets read `Current · 1–30 · 31–60 · 61–90 · 91–120 · 121+`.
  Format on the measure, not per visual.
- **Structure.** Lean on tables, numbered procedures, and Do / Don't pairs. Flag
  caveats with a bold lead-in (**Rule:**, **Retired —**).
- **Deltas.** Direction glyph + magnitude + a quiet comparison note:
  `▲ 8.4%` · *vs. prior month*. Never "up a lot".
- **No decorative emoji.** `✓ ✗` in documentation checklists and `▲ ▼` for
  deltas are the entire vocabulary.

**In our words:** *"The data carries the visual." · "Floating cards, not heavy
boxes." · "Color encodes meaning — never decoration."*

---

## 4. Visual foundations

Everything below is a token in [`styles.css`](styles.css) →
[`tokens/`](tokens/). Build on the variables; never invent a color.

**Color.** Teal `#15A0A6` and Deep Teal `#0E6E72` carry the brand; Light Teal,
Aqua, and Mint are fills. Slate Blue, Amber, and Rose appear **only** to keep
categories apart. Divisions are positional and fixed forever: AFP `#15A0A6` ·
ANC `#0E6E72` · IMP `#2E5E8C` · INL `#E0A458`. Sentiment is a fixed triad
(good `#4FA672` / neutral `#E0A458` / bad `#D9534F`); aging severity is a 6-step
ramp from deep teal to `#B5433F`. Text is muted slate (`#2D3748` / `#4A5568`) —
**never pure black**; ink tops out at `#1A2B33`. Accent teal is for fills and
strokes; when teal must carry text, use deep teal.

**Type.** **Segoe UI** is the only family — it ships with Windows and Power BI so
it renders for every viewer. Weights **400 and 600 only** (no 700, no light).
Sizes run small and dense because the canvas is 1280×720: callout 30 · title 20 ·
card 14 · header 12 · body 13 · data 10. Titles ≥20px get `-0.01em`; uppercase
eyebrows get `+1.2px`; body is untracked. **Tabular lining figures on every value
that can change** so columns don't shimmy. Consolas is optional for ledger
figures and is used for paths and hex values.

**Backgrounds.** Flat `#F7FAFC` page, `#FFFFFF` cards. **No** imagery, **no**
illustration, **no** gradients, **no** texture, **no** repeating pattern, **no**
photography. The page-to-card contrast is intentionally faint — the hairline plus
shadow do the grouping, so never darken the page to make cards pop. `#10282B`
(teal-ink) is allowed only as a letterbox *outside* the artifact.

**Cards.** Opaque white, **1px `#E2E8F0` hairline**, **radius 10**, layered ink
shadow (`0 1px 2px` @5% + `0 2px 8px` @6%). Head padding 11/14, body 14. Title
12px semibold slate. **No colored left-border accent cards, ever** — a category
gets a 9px swatch beside the label instead.

**Radii.** One per role: control 6 · chip 8 · card 10 · pill 999. Nothing else.

**Shadows.** Three levels, each two layered ink shadows reading as one soft edge:
resting (`--shadow-card`), raised (`--shadow-raised`, ambient layer tinted teal),
menu (`--shadow-menu`). Never stack levels, never exceed level 3, never darker
than 12% or blurrier than 32px. Shadows are ink-based, never black. No inner
shadows anywhere. Raising also strengthens the border to `#CBD5E0`.

**Transparency & blur.** Effectively none. State tints are flat teal washes
(5% / 10% / 14%) composited over white — not translucent surfaces. `backdrop-filter`
is banned. The **one** sanctioned transparency is a chart area fill at ≤10%,
because that is a *data* encoding, not a surface.

**Hover.** Rows and items wash at `--tint-hover` (5%); text shifts toward deep
teal; interactive cards lift to `--shadow-raised`. **Hover never moves an
element** — no `transform`, no translate. **Press / active.** `--tint-active`
(14%) — a color change, never a shrink. **Selected.** `--tint-selected` (10%),
or, for a checked slicer item and the active nav chip only, **solid teal with
white text** — the only sanctioned solid accent fill. **Disabled.** `#CBD5E0`
text, no tint, no shadow. **Focus.** `0 0 0 3px rgba(21,160,166,.28)`,
keyboard-only (`:focus-visible`), never removed without replacement.

**Motion.** Two durations — 120ms for tints, colors, and checks; 180ms for shadow
lifts, menu opens, and page fades — and one easing,
`cubic-bezier(.2,.6,.2,1)`. No delays, no bounces, no springs, no slides across
the screen. Menus fade and drop 2–4px. *If a transition is noticeable, it's too
long.*

**Layout.** Every report page shares identical geometry so navigation never
shifts: canvas 1280×720, slicer rail `x=10 w=150`, content seam `x=170`, logo box
`70×60` top-right, page title at the seam. Fixed elements: the left slicer rail,
the top-right logo, the title textbox. Spacing is an 8px base
(4/8/12/16/20/24/32/40); cards get generous interior padding. Rayfin web apps use
a sticky 64px header and one shared `max-w-1600` container for header *and*
content, so the navbar always aligns with the page.

**Data-viz.** Category gridlines off; value gridlines `#EDF2F7` at ~1px; axis and
legend 9–10px slate; axis titles usually off. Bars r2–3, lines 2.5px with 2.6px
dots. No 3D, no shadows on marks, no data labels unless the chart is the only
place the number appears.

**Imagery vibe.** There is none to have a vibe about — the brand is purely
geometric and tonal. Where an image is unavoidable, keep it cool, desaturated,
and grain-free so it doesn't fight the palette.

**Dark mode** exists for the **web only** ([`tokens/dark.css`](tokens/dark.css),
mapped from `rayfin-ui`): opaque surfaces derived from `#10282B`, lighter
foregrounds, brighter data hues, same craft. Reports, documents, and decks are
light only.

---

## 5. Iconography

**RCM reporting is deliberately icon-free.** There is no RCM icon font, no SVG
icon set, no PNG icon library, and no emoji in product UI — the data is the
visual. Nothing in the source repos ships an icon asset.

- **Unicode status glyphs are the whole native vocabulary.** `✓` / `✗` for
  Do/Don't and checklists; `▲` / `▼` for sentiment-colored deltas (▲ usually bad
  for aging and past-due, ▼ good); `▾` for a dropdown affordance; `·` as a
  separator. Small, monochrome, meaning-bearing — see the
  [Glyphs, not icons](preview/brand-glyphs.html) card.
- **No emoji.** Not in UI, not in report titles, not in card copy.
- **No illustration, no photography, no spot graphics.**
- **The one multicolor graphic** in the whole system is the Microsoft four-square
  mark on the Rayfin sign-in button (inlined in `AuthCard.jsx`, copied from
  `rayfin-ui/src/components/rcm/auth-page.tsx`).
- **When web chrome genuinely needs icons** — nav, toolbars, a sign-out affordance
  — `rayfin-ui` uses [**Lucide**](https://lucide.dev) at `strokeWidth={1.5}`,
  colored FG-2 or deep teal, which matches the monoline wordmark. **This is a
  substitution, flagged as such:** RCM ships no icon set of its own. Load Lucide
  from CDN rather than hand-drawing SVGs.
- **Logos are the only brand imagery.** Four PNG variants in [`assets/`](assets/);
  always pick the one that contrasts with its background, never recolor or
  reconstruct the wordmark.

---

## 6. Components

Reusable primitives, grouped by concern. Each directory holds `<Name>.jsx`,
`<Name>.d.ts`, `<Name>.prompt.md`, and one specimen card.

| Component | Group | What it is |
|---|---|---|
| **Button** | [`components/core/`](components/core/) | Primary (solid teal) / secondary / ghost / destructive action control |
| **StatusPill** | `components/core/` | Sentiment or active-filter pill — tint bg + darkened sentiment text |
| **Card** | `components/core/` | The visual container: opaque white, hairline, r10, layered shadow |
| **KpiCallout** | [`components/data/`](components/data/) | Big-number callout with label, sentiment delta, and 9px category swatch |
| **DataTable** | `components/data/` | The matrix: deep-teal header, horizontal rules only, tabular numerics |
| **BarChart** | `components/data/` | Column / horizontal bar chart in the positional division palette |
| **LineChart** | `components/data/` | Trend line with the sanctioned ≤10% area fill |
| **Slicer** | [`components/controls/`](components/controls/) | Left-rail filter list with solid-teal checks |
| **PageNav** | `components/controls/` | Report page / app view chips; active is solid teal |
| **Dropdown** | `components/controls/` | Context select — r6 control, menu at `--shadow-menu` |
| **AppShell** | [`components/app/`](components/app/) | The shared Rayfin app header + canvas |
| **AuthCard** | `components/app/` | The shared Rayfin Microsoft sign-in card |

**Where the inventory came from.** `Button`, `StatusPill`, `Card`, `KpiCallout`,
`DataTable`, `Slicer`, `PageNav`, `Dropdown`, `BarChart`, and `LineChart` are the
ten component recipes `DESIGN.md` §9–§10 specifies, one file each. `AppShell` and
`AuthCard` recreate `rayfin-ui/src/components/rcm/`.

**Intentional additions:** none. Primitives a design system "usually" has
(Toast, Avatar, Tabs, Tooltip, Sheet…) are deliberately absent — for web
applications those come from
[`rayfin-ui`](https://github.com/RCM-Industries-Inc/rayfin-ui), which is the
implementation authority, and reports have no counterpart for them.

---

## 7. Do & Don't

| ✅ Do | ❌ Don't |
|---|---|
| Apply the theme / import `styles.css` and build on the variables | Hardcode colors per visual |
| Use muted slate text (`#2D3748` / `#4A5568`) | Use pure black on white |
| Keep division colors in positional order | Re-map AFP/ANC/IMP/INL per chart |
| Tables: deep-teal header, horizontal rules only | Add vertical gridlines or zebra stripes |
| Floating cards with soft layered depth | Heavy outlines or loud drop shadows |
| Mark a category with the 9px label swatch | Tint the card or add a colored left border |
| Let the data speak; strip chart junk | Add decorative icons or emoji |
| Pick the logo variant that contrasts | Put the white logo on a light page |
| Keep every surface fully opaque | Reintroduce translucency, blur, or glass |
| Use Segoe UI at weight 400 / 600 | Introduce a third font or a 700 weight |
| Move nothing on hover — shadow and tint only | `transform` on hover or shrink on press |

---

## 8. Index — what's in this repo

**Root**

| Path | What it is |
|---|---|
| **`readme.md`** | This document — context, content fundamentals, visual foundations, iconography, component index. |
| [`DESIGN.md`](DESIGN.md) | **Canonical** report / branded-artifact spec: surfaces, elevation, state tints, motion, contrast audit, component recipes. |
| [`APPLICABILITY.md`](APPLICABILITY.md) | Scope map — which rules are universal vs. report / Office / web specific. |
| [`AGENTS.md`](AGENTS.md) | Repository instructions for agents working on the system itself. |
| [`SKILL.md`](SKILL.md) | Agent-Skills wrapper so this system works as a downloadable design skill. |
| [`styles.css`](styles.css) | **Global entry point** — `@import` list only. Consumers link this one file. |
| [`colors_and_type.css`](colors_and_type.css) | Compatibility shim for the historical single-file token bundle. |
| [`brand_standard.html`](brand_standard.html) | The original one-page visual brand standard. |
| [`thumbnail.html`](thumbnail.html) | Homepage tile. |
| [`github.md`](github.md) | Upstream source association and sync record. |

**Tokens** — [`tokens/`](tokens/): `fonts.css` · `colors.css` · `typography.css`
· `spacing.css` · `shape.css` · `motion.css` · `layout.css` · `primitives.css`
(element defaults + the `.card` primitive) · `dark.css` (web-only dark theme).

**Assets** — [`assets/`](assets/): `Logo_RCM_Teal.png` (light backgrounds) ·
`Logo_RCM_White.png` (dark) · `Logo_RCM_Ink.png` (neutral) · `Logo_RCM_Mark.png`
(tight spaces). No icon set — see [§5](#5-iconography).

**Themes** — [`themes/RCM_Industries_Modern_Teal.json`](themes/): the Power BI
enforcement layer. Apply it first; never override colors per visual.

**Components** — [`components/core/`](components/core/) ·
[`components/data/`](components/data/) ·
[`components/controls/`](components/controls/) ·
[`components/app/`](components/app/). See [§6](#6-components).

**UI kits**

| Kit | What it recreates |
|---|---|
| [`ui_kits/powerbi_report/`](ui_kits/powerbi_report/) | Interactive 1280×720 Power BI report — Executive Summary, AR Aging, Open Orders, 6 Month Forecast. |
| [`ui_kits/rayfin_app/`](ui_kits/rayfin_app/) | Rayfin web app (AR Review) — sign-in, dashboard, aging matrix, customer detail, light + dark. |

**Templates** — [`templates/`](templates/): starting folders a consuming project
can copy. `report-page/` (the 1280×720 report canvas) and
`rayfin-app-screen/` (the Rayfin app shell + content).

**Specimen cards** — [`preview/`](preview/): 20 foundation cards across Colors,
Type, Spacing, Shape, and Brand, rendered in the Design System tab.

**All illustrative data is fake.** Figures in the UI kits are shaped like RCM's
real measures but are not real company data.

---

<sub>RCM Industries Design System · Modern Teal v2.0. Built from
[`EreeceRCM/Design-System`](https://github.com/EreeceRCM/Design-System) and
[`RCM-Industries-Inc/rayfin-ui`](https://github.com/RCM-Industries-Inc/rayfin-ui).
When this document disagrees with `DESIGN.md`, `DESIGN.md` wins; for web
application behavior, `rayfin-ui` wins.</sub>
