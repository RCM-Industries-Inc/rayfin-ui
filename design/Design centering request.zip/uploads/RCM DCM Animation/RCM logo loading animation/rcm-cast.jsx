/* RCM casting splash — scene components for animations-v2 SceneStage.
   One persistent stage (die, shot sleeve, gantry takeout, HUD); scenes are
   deltas on shared params so every cut lands on the settled composition. */

const { SceneStage, useScene, TweaksPanel, TweakSection, TweakToggle, TweakRadio } = window;

const W = 1280, H = 720;

const INK = '#0B2226', PAGE = '#F7FAFC';
const SLAB = '#16383C', SLAB_D = '#0F2C30', EDGE = '#24545A';
const AMBER = '#E0A458', HOT = '#F7D3A0', MOLTEN = '#EFC387';
const DEEP = '#0E6E72';
const TXT_D = '#8FB3B7', TXT_L = '#4A5568';
const FONT = "'Segoe UI', 'Segoe UI Web', system-ui, sans-serif";

const clamp01 = (t) => (t < 0 ? 0 : t > 1 ? 1 : t);
const seg = (p, a, b) => clamp01((p - a) / (b - a));
const outQ = (t) => 1 - Math.pow(1 - t, 5);
const outC = (t) => 1 - Math.pow(1 - t, 3);
const inOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const E = (p, a, b, f) => (f || outQ)(seg(p, a, b));
const lerp = (a, b, t) => a + (b - a) * t;

function hex2rgb(h) {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function mix(a, b, t) {
  const A = hex2rgb(a), B = hex2rgb(b);
  return 'rgb(' + Math.round(lerp(A[0], B[0], t)) + ',' + Math.round(lerp(A[1], B[1], t))
    + ',' + Math.round(lerp(A[2], B[2], t)) + ')';
}

// ── persistent geometry ─────────────────────────────────────────────────────
const CAVITY = { x: 640, y: 400, w: 260 };
const CARRY = { x: 640, y: 300, w: 260 };
const HERO = { x: 640, y: 370, w: 470 };
const GRIP_W = 260;
const RAIL_Y = 100;
const MOLD = { top: 290, h: 210, w: 220, throw: 170 };

const LOGO_MASK = {
  WebkitMaskImage: 'url(assets/Logo_RCM_White.png)',
  maskImage: 'url(assets/Logo_RCM_White.png)',
  WebkitMaskSize: 'contain', maskSize: 'contain',
  WebkitMaskRepeat: 'no-repeat', maskRepeat: 'no-repeat',
  WebkitMaskPosition: 'center', maskPosition: 'center',
};

function lerpPos(a, b, t) {
  return { x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t), w: lerp(a.w, b.w, t) };
}

function Tick(props) {
  return (
    <div style={{
      position: 'absolute', left: props.x, top: props.y, width: props.w || 1,
      height: props.h || 1, background: props.c, opacity: props.o == null ? 1 : props.o,
    }} />
  );
}

function Label(props) {
  return (
    <div style={{
      position: 'absolute', left: props.x, top: props.y, font: '400 9px ' + FONT,
      letterSpacing: '1.2px', textTransform: 'uppercase', color: props.c,
      opacity: props.o, whiteSpace: 'nowrap', textAlign: props.align || 'left',
      transform: props.align === 'right' ? 'translateX(-100%)' : 'none',
    }}>{props.children}</div>
  );
}

// ── the shared machine + part + HUD, driven entirely by params ──────────────
function Composition(props) {
  const P = props.p, schematic = props.schematic;
  const day = P.day;
  const mfade = 1 - seg(day, 0.08, 0.7);
  const bg = mix(INK, PAGE, inOut(clamp01(day)));
  const txt = mix(TXT_D, TXT_L, clamp01(day * 1.25));

  const part = lerpPos(lerpPos(CAVITY, CARRY, P.lift), HERO, P.hero);
  const partH = part.w * 0.5625;
  const heat = clamp01(P.fill) * (1 - clamp01(P.cool));
  const partColor = mix(MOLTEN, DEEP, inOut(clamp01(P.cool)));
  const glow = 34 * heat;

  const openPx = MOLD.throw * P.open;
  const cx = lerp(lerp(1120, CAVITY.x, P.travel), part.x, clamp01(P.grip));
  const gripY = lerp(lerp(200, part.y, P.descend), 132, P.retract);
  const jawOff = GRIP_W / 2 + lerp(30, 5, clamp01(P.grip));
  const jawFade = mfade * (1 - seg(P.retract, 0.45, 1));

  const seamGlow = clamp01(P.fill) * (1 - P.open * 1.6) * mfade;
  const pulseX = lerp(278, 412, clamp01(P.shot));

  return (
    <div style={{ position: 'absolute', inset: 0, background: bg, overflow: 'hidden' }}>
      {/* floor haze — reads as foundry depth, gone by the time it's a light splash */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, height: 320,
        background: 'radial-gradient(60% 100% at 45% 100%, rgba(21,160,166,.14), rgba(21,160,166,0) 70%)',
        opacity: mfade,
      }} />

      <div style={{ position: 'absolute', inset: 0, transform: 'scale(' + P.cam + ')', transformOrigin: '50% 46%' }}>
        {/* ── gantry takeout robot ── */}
        <div style={{ position: 'absolute', inset: 0, opacity: mfade, zIndex: 6 }}>
          <Tick x={140} y={RAIL_Y} w={1000} h={10} c={SLAB} />
          <Tick x={140} y={RAIL_Y + 10} w={1000} h={1} c={EDGE} />
          <Tick x={140} y={RAIL_Y - 1} w={1000} h={1} c={EDGE} />
          {/* carriage */}
          <div style={{
            position: 'absolute', left: cx - 55, top: RAIL_Y - 13, width: 110, height: 36,
            background: SLAB, border: '1px solid ' + EDGE, borderRadius: 4,
          }}>
            <Tick x={14} y={16} w={28} h={2} c={EDGE} />
            <Tick x={68} y={16} w={28} h={2} c={EDGE} />
          </div>
          {/* telescoping column */}
          <div style={{
            position: 'absolute', left: cx - 11, top: RAIL_Y + 22,
            width: 22, height: Math.max(0, gripY - (RAIL_Y + 22)),
            background: SLAB_D, borderLeft: '1px solid ' + EDGE, borderRight: '1px solid ' + EDGE,
          }} />
          <div style={{
            position: 'absolute', left: cx - 6, top: RAIL_Y + 22,
            width: 12, height: Math.max(0, (gripY - (RAIL_Y + 22)) * 0.55), background: EDGE, opacity: 0.5,
          }} />
        </div>
        {/* gripper */}
        <div style={{ position: 'absolute', inset: 0, opacity: jawFade, zIndex: 7 }}>
          <div style={{
            position: 'absolute', left: cx - 46, top: gripY - 30, width: 92, height: 22,
            background: SLAB, border: '1px solid ' + EDGE, borderRadius: 3,
          }} />
          {[-1, 1].map((s) => (
            <div key={s} style={{
              position: 'absolute', left: cx + s * jawOff - 7, top: gripY - 26,
              width: 14, height: 54, background: SLAB, border: '1px solid ' + EDGE, borderRadius: 2,
            }} />
          ))}
        </div>

        {/* ── the part: RCM wordmark, cast then cooled ── */}
        <div style={{
          position: 'absolute', left: part.x - part.w / 2, top: part.y - partH / 2,
          width: part.w, height: partH, background: partColor,
          zIndex: P.lift > 0.01 ? 5 : 1,
          filter: glow > 0.5 ? 'drop-shadow(0 0 ' + glow + 'px rgba(224,164,88,' + (0.85 * heat) + '))' : 'none',
          ...LOGO_MASK,
        }} />

        {/* ── die halves (over the part: they hide the cavity until they open) ── */}
        {[-1, 1].map((s) => (
          <div key={s} style={{
            position: 'absolute', top: MOLD.top, width: MOLD.w, height: MOLD.h,
            left: s < 0 ? CAVITY.x - MOLD.w : CAVITY.x,
            transform: 'translateX(' + s * openPx + 'px)', zIndex: 4,
            background: SLAB, border: '1px solid ' + EDGE, opacity: mfade,
            borderRadius: s < 0 ? '4px 0 0 4px' : '0 4px 4px 0',
          }}>
            <Tick x={s < 0 ? 16 : MOLD.w - 44} y={18} w={28} h={2} c={EDGE} />
            <Tick x={s < 0 ? 16 : MOLD.w - 44} y={MOLD.h - 20} w={28} h={2} c={EDGE} />
          </div>
        ))}
        {/* parting-line glow while the cavity is full and still closed */}
        <div style={{
          position: 'absolute', left: CAVITY.x - 3, top: MOLD.top + 6, width: 6, height: MOLD.h - 12,
          background: mix(HOT, AMBER, 0.4), opacity: seamGlow, zIndex: 4,
          boxShadow: '0 0 26px 6px rgba(224,164,88,' + (0.55 * seamGlow) + ')',
        }} />

        {/* ── machine base + tie bars + shot sleeve ── */}
        <div style={{ position: 'absolute', inset: 0, opacity: mfade, zIndex: 2 }}>
          <Tick x={330} y={316} w={620} h={2} c={EDGE} o={0.55} />
          <Tick x={330} y={484} w={620} h={2} c={EDGE} o={0.55} />
          <div style={{
            position: 'absolute', left: 400, top: 500, width: 480, height: 56,
            background: SLAB_D, border: '1px solid ' + EDGE, borderRadius: 4,
          }} />
          <Tick x={450} y={556} w={40} h={30} c={SLAB_D} />
          <Tick x={790} y={556} w={40} h={30} c={SLAB_D} />
          {/* shot sleeve + plunger */}
          <div style={{
            position: 'absolute', left: 270, top: 462, width: 152, height: 24,
            background: SLAB_D, border: '1px solid ' + EDGE, borderRadius: 12, overflow: 'hidden',
          }}>
            <div style={{
              position: 'absolute', left: pulseX - 278, top: 3, width: 34, height: 16,
              background: mix(HOT, AMBER, 0.3), borderRadius: 8,
              opacity: clamp01(P.shot) * (1 - seg(P.shot, 0.88, 1)),
              boxShadow: '0 0 18px 4px rgba(224,164,88,.6)',
            }} />
          </div>
        </div>

        {/* ── schematic overlay ── */}
        {schematic && (
          <div style={{ position: 'absolute', inset: 0, opacity: mfade * 0.85, zIndex: 8 }}>
            <div style={{
              position: 'absolute', left: CAVITY.x - 134, top: CAVITY.y - 78, width: 268, height: 156,
              border: '1px dashed rgba(143,179,183,.45)', borderRadius: 3,
            }} />
            <Tick x={400} y={596} w={480} h={1} c="rgba(143,179,183,.4)" />
            <Tick x={400} y={590} w={1} h={13} c="rgba(143,179,183,.4)" />
            <Tick x={880} y={590} w={1} h={13} c="rgba(143,179,183,.4)" />
            <Label x={640} y={604} c={TXT_D} o={0.7} align="right">800 T · cicero</Label>
            <Label x={270} y={440} c={TXT_D} o={0.7}>shot sleeve</Label>
            <Label x={cx + 62} y={RAIL_Y - 4} c={TXT_D} o={0.7}>takeout · axis 1</Label>
            <Label x={422} y={268} c={TXT_D} o={0.7}>die · rcm wordmark</Label>
            <Tick x={CAVITY.x - 170} y={CAVITY.y} w={30} h={1} c="rgba(143,179,183,.35)" />
            <Tick x={CAVITY.x + 140} y={CAVITY.y} w={30} h={1} c="rgba(143,179,183,.35)" />
          </div>
        )}
      </div>

      {/* ── HUD (unscaled) ── */}
      <div style={{
        position: 'absolute', left: 44, top: 40, font: '600 10px ' + FONT,
        letterSpacing: '1.2px', textTransform: 'uppercase', color: txt, opacity: 0.75,
      }}>RCM Industries</div>

      <div style={{
        position: 'absolute', left: 0, right: 0, top: 596, display: 'flex',
        flexDirection: 'column', alignItems: 'center', gap: 14,
      }}>
        <div style={{
          font: '400 13px ' + FONT, color: txt,
          fontVariantNumeric: 'tabular-nums', letterSpacing: '.01em',
        }}>{P.status}</div>
        <div style={{
          width: 360, height: 2, background: mix('#1E4A4F', '#E2E8F0', clamp01(day)),
          position: 'relative', borderRadius: 999,
        }}>
          <div style={{
            position: 'absolute', left: 0, top: 0, height: 2, borderRadius: 999,
            width: (360 * clamp01(P.prog)) + 'px',
            background: mix(AMBER, DEEP, inOut(clamp01(P.cool))),
          }} />
        </div>
      </div>
    </div>
  );
}

const BASE = {
  shot: 0, fill: 0, open: 0, travel: 0, descend: 0, grip: 0, lift: 0,
  hero: 0, cool: 0, day: 0, retract: 0, prog: 0, cam: 1, status: '',
};

function Cast(props) {
  const s = useScene(), p = s.progress;
  return <Composition schematic={props.schematic} p={{
    ...BASE,
    shot: E(p, 0.06, 0.72, outC),
    fill: E(p, 0.42, 1, outC),
    travel: 0.45 * E(p, 0.3, 1, outC),
    prog: 0.30 * inOut(p),
    cam: lerp(1.0, 1.02, inOut(p)),
    status: p < 0.42 ? 'Clamping die' : 'Injecting shot',
  }} />;
}

function Extract(props) {
  const s = useScene(), p = s.progress;
  return <Composition schematic={props.schematic} p={{
    ...BASE,
    shot: 1, fill: 1,
    open: E(p, 0, 0.36),
    travel: lerp(0.45, 1, E(p, 0, 0.32, outC)),
    descend: E(p, 0.28, 0.62, inOut),
    grip: E(p, 0.6, 0.74, outC),
    lift: E(p, 0.72, 1, outC),
    prog: lerp(0.30, 0.82, inOut(p)),
    cam: lerp(1.02, 1.05, inOut(p)),
    status: p < 0.36 ? 'Opening die' : p < 0.72 ? 'Gripping part' : 'Extracting',
  }} />;
}

function Settle(props) {
  const s = useScene(), p = s.progress;
  return <Composition schematic={props.schematic} p={{
    ...BASE,
    shot: 1, fill: 1, open: 1, travel: 1, descend: 1,
    grip: 1 - E(p, 0, 0.2, outC),
    retract: E(p, 0.12, 0.58, inOut),
    lift: 1,
    hero: E(p, 0.1, 1),
    cool: E(p, 0, 0.72, outC),
    day: E(p, 0.2, 1, inOut),
    prog: lerp(0.82, 1, outC(p)),
    cam: lerp(1.05, 1.0, inOut(p)),
    status: p < 0.55 ? 'Cooling' : 'Ready',
  }} />;
}

function RCMCastSplash() {
  const tw = window.useTweaks(window.TWEAK_DEFAULTS || {});
  const t = tw[0], setTweak = tw[1];
  const schematic = t.fidelity === 'schematic';
  const wrap = (C) => (p) => <C {...p} schematic={schematic} />;
  return (
    <React.Fragment>
      <SceneStage width={W} height={H} bg={INK}
        scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        {{ Cast: wrap(Cast), Extract: wrap(Extract), Settle: wrap(Settle) }}
      </SceneStage>
      <TweaksPanel>
        <TweakSection label="Machine" />
        <TweakRadio label="Fidelity" value={t.fidelity} options={['abstract', 'schematic']}
          onChange={(v) => setTweak('fidelity', v)} />
        <TweakSection label="Editor" />
        <TweakToggle label="Motion editor" value={t.motionEditor}
          onChange={(v) => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </React.Fragment>
  );
}

window.RCMCastSplash = RCMCastSplash;
